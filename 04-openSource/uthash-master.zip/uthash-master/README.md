
[![Build status](https://travis-ci.org/Quuxplusone/uthash.svg?branch=travis-ci)](https://travis-ci.org/troydhanson/uthash)

Documentation for uthash is available at:

http://troydhanson.github.com/uthash/


